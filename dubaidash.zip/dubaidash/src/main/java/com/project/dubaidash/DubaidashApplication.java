package com.project.dubaidash;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DubaidashApplication {

	public static void main(String[] args) {
		SpringApplication.run(DubaidashApplication.class, args);
	}

}
