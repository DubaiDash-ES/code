package com.project.dubaidash;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DubaidashApplicationTests {

	@Test
	void contextLoads() {
	}

}
